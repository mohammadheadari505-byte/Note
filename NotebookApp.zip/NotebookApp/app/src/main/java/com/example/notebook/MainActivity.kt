package com.example.notebook

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.View
import android.widget.EditText
import android.widget.PopupMenu
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.notebook.adapter.ListItem
import com.example.notebook.adapter.MainListAdapter
import com.example.notebook.data.AppDatabase
import com.example.notebook.data.Folder
import com.example.notebook.data.Note
import com.example.notebook.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: MainListAdapter
    private val db by lazy { AppDatabase.getInstance(this) }
    private var dataJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        adapter = MainListAdapter(
            onFolderClick = { folder ->
                val intent = Intent(this, FolderActivity::class.java)
                intent.putExtra("folderId", folder.id)
                intent.putExtra("folderName", folder.name)
                startActivity(intent)
            },
            onNoteClick = { note ->
                val intent = Intent(this, NoteEditActivity::class.java)
                intent.putExtra("noteId", note.id)
                startActivity(intent)
            },
            onFolderDelete = { folder -> confirmDeleteFolder(folder) },
            onNoteDelete = { note -> confirmDeleteNote(note) }
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener { showAddMenu() }

        observeData()
    }

    private fun observeData() {
        dataJob?.cancel()
        dataJob = lifecycleScope.launch {
            combine(
                db.folderDao().getAllFolders(),
                db.noteDao().getRootNotes()
            ) { folders, notes ->
                val items = mutableListOf<ListItem>()
                items.addAll(folders.map { ListItem.FolderItem(it) })
                items.addAll(notes.map { ListItem.NoteItem(it) })
                items
            }.collect { items ->
                adapter.submitList(items)
                binding.emptyView.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun doSearch(query: String) {
        dataJob?.cancel()
        dataJob = lifecycleScope.launch {
            db.noteDao().search(query).collect { notes ->
                val items = notes.map { ListItem.NoteItem(it) }
                adapter.submitList(items)
                binding.emptyView.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun showAddMenu() {
        val popup = PopupMenu(this, binding.fabAdd)
        popup.menu.add(0, 1, 0, getString(R.string.new_note))
        popup.menu.add(0, 2, 1, getString(R.string.new_folder))
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> {
                    startActivity(Intent(this, NoteEditActivity::class.java))
                    true
                }
                2 -> {
                    showNewFolderDialog()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun showNewFolderDialog() {
        val editText = EditText(this)
        editText.hint = getString(R.string.folder_name)
        editText.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        val padding = (16 * resources.displayMetrics.density).toInt()
        editText.setPadding(padding, padding, padding, padding)

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.new_folder))
            .setView(editText)
            .setPositiveButton(getString(R.string.create)) { _, _ ->
                val name = editText.text.toString().trim()
                if (name.isNotEmpty()) {
                    lifecycleScope.launch {
                        db.folderDao().insert(Folder(name = name))
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun confirmDeleteFolder(folder: Folder) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_folder_title))
            .setMessage(getString(R.string.delete_folder_message, folder.name))
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                lifecycleScope.launch { db.folderDao().delete(folder) }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun confirmDeleteNote(note: Note) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_note_title))
            .setMessage(getString(R.string.delete_note_message))
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                lifecycleScope.launch { db.noteDao().delete(note) }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        searchView.queryHint = getString(R.string.search_hint)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false
            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText.isNullOrBlank()) {
                    observeData()
                } else {
                    doSearch(newText)
                }
                return true
            }
        })
        return true
    }
}
