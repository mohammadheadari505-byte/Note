package com.example.notebook

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.notebook.adapter.NoteAdapter
import com.example.notebook.data.AppDatabase
import com.example.notebook.data.Note
import com.example.notebook.databinding.ActivityFolderBinding
import kotlinx.coroutines.launch

class FolderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFolderBinding
    private lateinit var adapter: NoteAdapter
    private val db by lazy { AppDatabase.getInstance(this) }
    private var folderId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFolderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        folderId = intent.getLongExtra("folderId", -1)
        val folderName = intent.getStringExtra("folderName") ?: getString(R.string.app_name)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.title = folderName
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = NoteAdapter(
            onNoteClick = { note ->
                val intent = Intent(this, NoteEditActivity::class.java)
                intent.putExtra("noteId", note.id)
                startActivity(intent)
            },
            onNoteDelete = { note -> confirmDeleteNote(note) }
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener {
            val intent = Intent(this, NoteEditActivity::class.java)
            intent.putExtra("folderId", folderId)
            startActivity(intent)
        }

        lifecycleScope.launch {
            db.noteDao().getNotesInFolder(folderId).collect { notes ->
                adapter.submitList(notes)
                binding.emptyView.visibility = if (notes.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun confirmDeleteNote(note: Note) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_note_title))
            .setMessage(getString(R.string.delete_note_message))
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                lifecycleScope.launch { db.noteDao().delete(note) }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
}
