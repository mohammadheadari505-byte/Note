package com.example.notebook

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.addCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.notebook.data.AppDatabase
import com.example.notebook.data.Note
import com.example.notebook.databinding.ActivityNoteEditBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NoteEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNoteEditBinding
    private val db by lazy { AppDatabase.getInstance(this) }
    private var noteId: Long = -1
    private var folderId: Long? = null
    private var existingNote: Note? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNoteEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { saveNote() }

        onBackPressedDispatcher.addCallback(this) {
            saveNote()
        }

        noteId = intent.getLongExtra("noteId", -1)
        if (intent.hasExtra("folderId")) {
            folderId = intent.getLongExtra("folderId", -1)
        }

        binding.editTitle.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        binding.editContent.textDirection = View.TEXT_DIRECTION_FIRST_STRONG

        if (noteId != -1L) {
            binding.lastEditedText.visibility = View.VISIBLE
            lifecycleScope.launch {
                val note = db.noteDao().getById(noteId)
                existingNote = note
                note?.let {
                    binding.editTitle.setText(it.title)
                    binding.editContent.setText(it.content)
                    updateLastEditedLabel(it.lastEditedAt)
                }
                invalidateOptionsMenu()
            }
        } else {
            binding.lastEditedText.visibility = View.GONE
        }
    }

    private fun updateLastEditedLabel(timestamp: Long) {
        val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
        binding.lastEditedText.text = getString(R.string.last_edited, sdf.format(Date(timestamp)))
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_note_edit, menu)
        menu.findItem(R.id.action_delete)?.isVisible = existingNote != null
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_save -> {
                saveNote()
                true
            }
            R.id.action_delete -> {
                confirmDelete()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun saveNote() {
        val title = binding.editTitle.text.toString().trim()
        val content = binding.editContent.text.toString().trim()

        if (title.isEmpty() && content.isEmpty()) {
            finish()
            return
        }

        val finalTitle = if (title.isEmpty()) content.take(30) else title

        lifecycleScope.launch {
            val current = existingNote
            if (current != null) {
                db.noteDao().update(
                    current.copy(
                        title = finalTitle,
                        content = content,
                        lastEditedAt = System.currentTimeMillis()
                    )
                )
            } else {
                db.noteDao().insert(
                    Note(
                        folderId = folderId,
                        title = finalTitle,
                        content = content,
                        lastEditedAt = System.currentTimeMillis()
                    )
                )
            }
            finish()
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.delete_note_title))
            .setMessage(getString(R.string.delete_note_message))
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                lifecycleScope.launch {
                    existingNote?.let { db.noteDao().delete(it) }
                    finish()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
}
