package com.example.notebook.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.notebook.data.Folder
import com.example.notebook.data.Note
import com.example.notebook.databinding.ItemFolderBinding
import com.example.notebook.databinding.ItemNoteBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class ListItem {
    data class FolderItem(val folder: Folder) : ListItem()
    data class NoteItem(val note: Note) : ListItem()
}

class MainListAdapter(
    private val onFolderClick: (Folder) -> Unit,
    private val onNoteClick: (Note) -> Unit,
    private val onFolderDelete: (Folder) -> Unit,
    private val onNoteDelete: (Note) -> Unit
) : ListAdapter<ListItem, RecyclerView.ViewHolder>(DIFF_CALLBACK) {

    companion object {
        private const val TYPE_FOLDER = 0
        private const val TYPE_NOTE = 1

        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListItem>() {
            override fun areItemsTheSame(oldItem: ListItem, newItem: ListItem): Boolean {
                return when {
                    oldItem is ListItem.FolderItem && newItem is ListItem.FolderItem ->
                        oldItem.folder.id == newItem.folder.id
                    oldItem is ListItem.NoteItem && newItem is ListItem.NoteItem ->
                        oldItem.note.id == newItem.note.id
                    else -> false
                }
            }

            override fun areContentsTheSame(oldItem: ListItem, newItem: ListItem): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is ListItem.FolderItem -> TYPE_FOLDER
            is ListItem.NoteItem -> TYPE_NOTE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_FOLDER) {
            FolderViewHolder(ItemFolderBinding.inflate(inflater, parent, false))
        } else {
            NoteViewHolder(ItemNoteBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is ListItem.FolderItem -> (holder as FolderViewHolder).bind(item.folder)
            is ListItem.NoteItem -> (holder as NoteViewHolder).bind(item.note)
        }
    }

    inner class FolderViewHolder(private val binding: ItemFolderBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(folder: Folder) {
            binding.folderName.text = folder.name
            binding.root.setOnClickListener { onFolderClick(folder) }
            binding.deleteButton.setOnClickListener { onFolderDelete(folder) }
        }
    }

    inner class NoteViewHolder(private val binding: ItemNoteBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(note: Note) {
            binding.noteTitle.text = note.title
            binding.notePreview.text = note.content
            val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
            binding.noteDate.text = sdf.format(Date(note.lastEditedAt))
            binding.root.setOnClickListener { onNoteClick(note) }
            binding.deleteButton.setOnClickListener { onNoteDelete(note) }
        }
    }
}
